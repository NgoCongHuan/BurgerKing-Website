﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BurgerKing.Models
{
    public class PaymentType
    {
        public const string Cash = "Tiền mặt";
        public const string Bank = "Chuyển khoản";
    }
}